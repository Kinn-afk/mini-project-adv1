// Storage Manager Module - Handles localStorage operations
export class StorageManager {
    constructor() {
        this.STORAGE_KEY = 'shoppingListApp_items';
        console.log('💾 StorageManager initialized');
        console.log('Storage key:', this.STORAGE_KEY);
        
        // Test localStorage availability
        this.testLocalStorage();
    }
    
    testLocalStorage() {
        try {
            const testKey = 'storage_test';
            localStorage.setItem(testKey, 'test');
            localStorage.removeItem(testKey);
            console.log('✅ localStorage is available');
            return true;
        } catch (error) {
            console.error('❌ localStorage is not available:', error);
            alert('Warning: Your browser does not support localStorage. Your data will not be saved.');
            return false;
        }
    }
    
    // Save items to localStorage
    saveItems(items) {
        console.log('💾 Saving items to localStorage:', items);
        
        try {
            const itemsToSave = items.map(item => {
                // Create a clean object without circular references or methods
                return {
                    id: item.id,
                    name: item.name,
                    quantity: item.quantity,
                    category: item.category,
                    completed: item.completed,
                    createdAt: item.createdAt,
                    updatedAt: item.updatedAt || new Date().toISOString()
                };
            });
            
            const jsonString = JSON.stringify(itemsToSave);
            localStorage.setItem(this.STORAGE_KEY, jsonString);
            console.log(`✅ Saved ${items.length} items to localStorage`);
            return true;
        } catch (error) {
            console.error('❌ Error saving to localStorage:', error);
            this.showStorageError('save');
            return false;
        }
    }
    
    // Load items from localStorage
    loadItems() {
        console.log('💾 Loading items from localStorage');
        
        try {
            const jsonString = localStorage.getItem(this.STORAGE_KEY);
            
            if (!jsonString) {
                console.log('ℹ️ No saved items found in localStorage');
                return [];
            }
            
            const items = JSON.parse(jsonString);
            
            // Validate loaded data
            if (!Array.isArray(items)) {
                console.error('❌ Invalid data format in localStorage');
                this.clearStorage();
                return [];
            }
            
            console.log(`✅ Loaded ${items.length} items from localStorage`);
            
            // Ensure all items have required properties
            return items.map(item => ({
                id: item.id || Date.now() + Math.random(),
                name: item.name || 'Unknown Item',
                quantity: typeof item.quantity === 'number' ? item.quantity : 1,
                category: item.category || 'other',
                completed: Boolean(item.completed),
                createdAt: item.createdAt || new Date().toISOString(),
                updatedAt: item.updatedAt || new Date().toISOString()
            }));
            
        } catch (error) {
            console.error('❌ Error loading from localStorage:', error);
            this.showStorageError('load');
            return [];
        }
    }
    
    // Clear all data from localStorage
    clearStorage() {
        console.log('🗑️ Clearing localStorage');
        
        try {
            localStorage.removeItem(this.STORAGE_KEY);
            console.log('✅ localStorage cleared');
            return true;
        } catch (error) {
            console.error('❌ Error clearing localStorage:', error);
            return false;
        }
    }
    
    // Get storage statistics
    getStorageStats() {
        try {
            const jsonString = localStorage.getItem(this.STORAGE_KEY);
            if (!jsonString) {
                return { size: 0, items: 0 };
            }
            
            const items = JSON.parse(jsonString);
            const size = new Blob([jsonString]).size; // Size in bytes
            
            return {
                size: size,
                sizeKB: (size / 1024).toFixed(2),
                sizeMB: (size / (1024 * 1024)).toFixed(4),
                items: items.length
            };
        } catch (error) {
            console.error('Error getting storage stats:', error);
            return { size: 0, items: 0 };
        }
    }
    
    // Export data as JSON file
    exportData() {
        try {
            const items = this.loadItems();
            const jsonString = JSON.stringify(items, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `shopping-list-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            
            URL.revokeObjectURL(url);
            console.log('✅ Data exported successfully');
            return true;
        } catch (error) {
            console.error('❌ Error exporting data:', error);
            return false;
        }
    }
    
    // Import data from JSON file
    importData(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const jsonString = event.target.result;
                    const items = JSON.parse(jsonString);
                    
                    if (!Array.isArray(items)) {
                        throw new Error('Invalid file format: expected an array of items');
                    }
                    
                    // Validate each item
                    const validItems = items.filter(item => 
                        item && 
                        typeof item === 'object' &&
                        item.name && 
                        typeof item.name === 'string'
                    );
                    
                    if (validItems.length === 0) {
                        throw new Error('No valid items found in file');
                    }
                    
                    // Save imported items
                    this.saveItems(validItems);
                    console.log(`✅ Imported ${validItems.length} items from file`);
                    resolve(validItems.length);
                    
                } catch (error) {
                    console.error('❌ Error importing data:', error);
                    reject(error);
                }
            };
            
            reader.onerror = (error) => {
                console.error('❌ Error reading file:', error);
                reject(error);
            };
            
            reader.readAsText(file);
        });
    }
    
    // Backup data with timestamp
    backupData() {
        try {
            const items = this.loadItems();
            const backup = {
                version: '1.0',
                timestamp: new Date().toISOString(),
                itemCount: items.length,
                data: items
            };
            
            const backupKey = `${this.STORAGE_KEY}_backup_${Date.now()}`;
            localStorage.setItem(backupKey, JSON.stringify(backup));
            
            // Keep only last 5 backups
            this.cleanupOldBackups();
            
            console.log('✅ Data backed up successfully');
            return backupKey;
        } catch (error) {
            console.error('❌ Error backing up data:', error);
            return null;
        }
    }
    
    // Clean up old backups
    cleanupOldBackups() {
        try {
            const backups = [];
            
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith(`${this.STORAGE_KEY}_backup_`)) {
                    backups.push(key);
                }
            }
            
            // Sort by timestamp (newest first)
            backups.sort((a, b) => {
                const timestampA = parseInt(a.split('_').pop());
                const timestampB = parseInt(b.split('_').pop());
                return timestampB - timestampA;
            });
            
            // Remove old backups (keep only last 5)
            if (backups.length > 5) {
                const toRemove = backups.slice(5);
                toRemove.forEach(key => {
                    localStorage.removeItem(key);
                    console.log(`🗑️ Removed old backup: ${key}`);
                });
            }
        } catch (error) {
            console.error('Error cleaning up backups:', error);
        }
    }
    
    // Show storage error message
    showStorageError(operation) {
        const errorMessages = {
            save: 'Could not save your data. Please check if localStorage is enabled.',
            load: 'Could not load your saved data. Please refresh the page.',
            clear: 'Could not clear storage. Please try again.'
        };
        
        const message = errorMessages[operation] || 'A storage error occurred.';
        
        // Show user-friendly error
        if (typeof document !== 'undefined') {
            const errorDiv = document.createElement('div');
            errorDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #f8d7da;
                color: #721c24;
                padding: 15px 20px;
                border-radius: 5px;
                border: 1px solid #f5c6cb;
                z-index: 10000;
                max-width: 300px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            `;
            errorDiv.innerHTML = `
                <strong>Storage Error</strong>
                <p style="margin: 5px 0 0 0; font-size: 14px;">${message}</p>
            `;
            
            document.body.appendChild(errorDiv);
            
            setTimeout(() => {
                errorDiv.style.opacity = '0';
                errorDiv.style.transition = 'opacity 0.5s';
                setTimeout(() => {
                    if (errorDiv.parentNode) {
                        errorDiv.parentNode.removeChild(errorDiv);
                    }
                }, 500);
            }, 5000);
        }
    }
    
    // Check storage quota
    checkStorageQuota() {
        try {
            const testData = 'x'.repeat(1024 * 1024); // 1MB of data
            localStorage.setItem('quota_test', testData);
            localStorage.removeItem('quota_test');
            return { available: true, message: 'Storage quota is sufficient' };
        } catch (error) {
            if (error.name === 'QuotaExceededError') {
                return { 
                    available: false, 
                    message: 'Storage quota exceeded. Please clear some data.' 
                };
            }
            return { 
                available: false, 
                message: 'Unable to check storage quota' 
            };
        }
    }
}