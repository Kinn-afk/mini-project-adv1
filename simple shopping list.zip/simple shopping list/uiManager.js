// UI Manager Module - Handles all DOM manipulation
export class UIManager {
    constructor() {
        console.log('🎨 UIManager initialized');
        
        // Cache DOM elements
        this.listContainer = document.getElementById('shoppingList');
        this.totalItemsEl = document.getElementById('totalItems');
        this.pendingItemsEl = document.getElementById('pendingItems');
        this.completedItemsEl = document.getElementById('completedItems');
        this.categoryCountEl = document.getElementById('categoryCount');
        
        // Validate DOM elements
        this.validateDOMElements();
        
        this.currentFilter = 'all';
        
        // Event handlers that will be set from main.js
        this.onItemToggle = null;
        this.onItemDelete = null;
        this.onFilterChange = null;
        
        console.log('✅ UIManager setup complete');
    }
    
    validateDOMElements() {
        const elements = {
            'shoppingList': this.listContainer,
            'totalItems': this.totalItemsEl,
            'pendingItems': this.pendingItemsEl,
            'completedItems': this.completedItemsEl,
            'categoryCount': this.categoryCountEl
        };
        
        for (const [name, element] of Object.entries(elements)) {
            if (!element) {
                console.error(`❌ Required DOM element not found: ${name}`);
            } else {
                console.log(`✅ Found element: ${name}`);
            }
        }
    }
    
    // Render the entire shopping list
    renderList(items) {
        console.log('🎨 Rendering list with', items.length, 'items');
        
        if (!this.listContainer) {
            console.error('List container not found!');
            return;
        }
        
        // Clear the container
        this.listContainer.innerHTML = '';
        
        // Show empty state if no items
        if (items.length === 0) {
            this.showEmptyState();
            return;
        }
        
        // Filter items based on current filter
        let filteredItems = items;
        if (this.currentFilter === 'pending') {
            filteredItems = items.filter(item => !item.completed);
        } else if (this.currentFilter === 'completed') {
            filteredItems = items.filter(item => item.completed);
        }
        
        console.log(`🎨 Filter "${this.currentFilter}" applied: showing ${filteredItems.length} items`);
        
        // Create and append each item
        filteredItems.forEach((item, index) => {
            const itemElement = this.createListItem(item, index);
            if (itemElement) {
                this.listContainer.appendChild(itemElement);
            }
        });
        
        console.log('✅ List rendered successfully');
    }
    
    // Create a single list item element
    createListItem(item, index) {
        console.log('Creating list item:', item);
        
        const itemElement = document.createElement('div');
        itemElement.className = `list-item ${item.completed ? 'completed' : 'pending'}`;
        itemElement.dataset.id = item.id;
        itemElement.dataset.category = item.category;
        
        // Add animation delay for staggered entrance
        itemElement.style.animationDelay = `${index * 0.05}s`;
        
        // Category icons mapping
        const categoryIcons = {
            'groceries': '🛒',
            'produce': '🥦',
            'dairy': '🥛',
            'meat': '🥩',
            'bakery': '🍞',
            'beverages': '🥤',
            'household': '🏠',
            'other': '📦'
        };
        
        // Category names mapping
        const categoryNames = {
            'groceries': 'Groceries',
            'produce': 'Produce',
            'dairy': 'Dairy',
            'meat': 'Meat',
            'bakery': 'Bakery',
            'beverages': 'Beverages',
            'household': 'Household',
            'other': 'Other'
        };
        
        const icon = categoryIcons[item.category] || '📦';
        const categoryName = categoryNames[item.category] || 'Other';
        
        itemElement.innerHTML = `
            <div class="item-checkbox ${item.completed ? 'checked' : ''}">
                ${item.completed ? '✓' : ''}
            </div>
            <div class="item-content">
                <div class="item-name">${this.escapeHTML(item.name)}</div>
                <div class="item-details">
                    <span class="item-quantity">${item.quantity}x</span>
                    <span class="item-category">
                        ${icon} ${categoryName}
                    </span>
                </div>
            </div>
            <button class="item-delete" aria-label="Delete ${this.escapeHTML(item.name)}">
                <i class="fas fa-trash"></i>
            </button>
        `;
        
        // Add event listeners
        const checkbox = itemElement.querySelector('.item-checkbox');
        if (checkbox && this.onItemToggle) {
            checkbox.addEventListener('click', () => {
                console.log('Checkbox clicked for item:', item.id);
                this.onItemToggle(item.id);
            });
        }
        
        const deleteBtn = itemElement.querySelector('.item-delete');
        if (deleteBtn && this.onItemDelete) {
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Delete button clicked for item:', item.id);
                this.onItemDelete(item.id);
            });
        }
        
        // Add click listener to entire item
        itemElement.addEventListener('click', (e) => {
            if (e.target !== deleteBtn && !deleteBtn.contains(e.target)) {
                console.log('Item clicked:', item.id);
                if (this.onItemToggle) {
                    this.onItemToggle(item.id);
                }
            }
        });
        
        return itemElement;
    }
    
    // Show empty state message
    showEmptyState() {
        console.log('Showing empty state');
        
        if (!this.listContainer) return;
        
        let message = "Your shopping list is empty";
        let submessage = "Add items above to get started!";
        let icon = "fas fa-shopping-basket";
        
        if (this.currentFilter === 'pending') {
            message = "No pending items";
            submessage = "All items are completed! 🎉";
            icon = "fas fa-check-circle";
        } else if (this.currentFilter === 'completed') {
            message = "No completed items";
            submessage = "Complete some items first";
            icon = "fas fa-clock";
        }
        
        this.listContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">
                    <i class="${icon}"></i>
                </div>
                <h3>${message}</h3>
                <p>${submessage}</p>
            </div>
        `;
    }
    
    // Update statistics display
    updateStats(stats) {
        console.log('📊 Updating stats:', stats);
        
        if (this.totalItemsEl) this.totalItemsEl.textContent = stats.total;
        if (this.pendingItemsEl) this.pendingItemsEl.textContent = stats.pending;
        if (this.completedItemsEl) this.completedItemsEl.textContent = stats.completed;
        if (this.categoryCountEl) this.categoryCountEl.textContent = stats.categories;
        
        // Add animation to stat changes
        this.animateStatUpdate();
        
        console.log('✅ Stats updated');
    }
    
    // Animate stat numbers
    animateStatUpdate() {
        const statElements = [
            this.totalItemsEl,
            this.pendingItemsEl,
            this.completedItemsEl,
            this.categoryCountEl
        ];
        
        statElements.forEach(el => {
            if (el) {
                el.classList.add('stat-update');
                setTimeout(() => {
                    el.classList.remove('stat-update');
                }, 300);
            }
        });
    }
    
    // Apply filter to the list
    applyFilter(filter, items) {
        console.log('🎯 Applying filter:', filter);
        this.currentFilter = filter;
        
        // Update active filter button
        document.querySelectorAll('.filter-tab').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === filter) {
                btn.classList.add('active');
            }
        });
        
        // Re-render list with filter
        this.renderList(items);
        
        console.log(`✅ Filter "${filter}" applied`);
    }
    
    // Clear input fields
    clearInputs() {
        const itemInput = document.getElementById('itemInput');
        const quantityInput = document.getElementById('quantityInput');
        const categorySelect = document.getElementById('categorySelect');
        
        if (itemInput) itemInput.value = '';
        if (quantityInput) quantityInput.value = '1';
        if (categorySelect) categorySelect.value = 'groceries';
        
        // Focus back on item input
        setTimeout(() => {
            if (itemInput) {
                itemInput.focus();
                itemInput.classList.add('pulse');
                setTimeout(() => itemInput.classList.remove('pulse'), 600);
            }
        }, 100);
    }
    
    // Show notification/toast
    showNotification(message, type = 'info') {
        console.log(`📢 Showing ${type} notification:`, message);
        
        // Remove existing toast
        const existingToast = document.querySelector('.toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        // Create new toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-circle',
            'warning': 'fas fa-exclamation-triangle',
            'info': 'fas fa-info-circle'
        };
        
        toast.innerHTML = `
            <i class="${icons[type] || icons.info}"></i>
            <span>${this.escapeHTML(message)}</span>
        `;
        
        document.body.appendChild(toast);
        
        // Remove after 3 seconds
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // Highlight new item (visual feedback)
    highlightItem(itemId) {
        console.log('✨ Highlighting item:', itemId);
        const itemElement = document.querySelector(`[data-id="${itemId}"]`);
        if (itemElement) {
            itemElement.classList.add('highlight');
            setTimeout(() => {
                itemElement.classList.remove('highlight');
            }, 1000);
        }
    }
    
    // Toggle item completion with animation
    toggleItemAnimation(itemId, completed) {
        console.log(`🔄 Toggling animation for item ${itemId}:`, completed ? 'completed' : 'pending');
        const itemElement = document.querySelector(`[data-id="${itemId}"]`);
        if (itemElement) {
            const checkbox = itemElement.querySelector('.item-checkbox');
            const itemName = itemElement.querySelector('.item-name');
            
            if (completed) {
                itemElement.classList.add('completed');
                itemElement.classList.remove('pending');
                
                if (checkbox) {
                    checkbox.classList.add('checked');
                    checkbox.innerHTML = '✓';
                }
                
                if (itemName) {
                    itemName.style.textDecoration = 'line-through';
                    itemName.style.opacity = '0.7';
                }
            } else {
                itemElement.classList.remove('completed');
                itemElement.classList.add('pending');
                
                if (checkbox) {
                    checkbox.classList.remove('checked');
                    checkbox.innerHTML = '';
                }
                
                if (itemName) {
                    itemName.style.textDecoration = 'none';
                    itemName.style.opacity = '1';
                }
            }
            
            // Add pulse animation
            itemElement.classList.add('pulse');
            setTimeout(() => {
                itemElement.classList.remove('pulse');
            }, 300);
        }
    }
    
    // Utility function to escape HTML
    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}