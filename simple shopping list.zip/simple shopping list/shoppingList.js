// Shopping List Module - Manages the array of items
export class ShoppingList {
    constructor() {
        this.items = [];
        this.nextId = 1;
        console.log('🛒 ShoppingList initialized');
    }
    
    addItem(itemData) {
        console.log('Adding item to list:', itemData);
        
        const newItem = {
            id: this.nextId++,
            name: itemData.name,
            quantity: itemData.quantity || 1,
            category: itemData.category || 'groceries',
            completed: false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        // Validate item
        if (!this.validateItem(newItem)) {
            throw new Error('Invalid item data');
        }
        
        this.items.push(newItem);
        console.log('Item added successfully. Total items:', this.items.length);
        return newItem;
    }
    
    validateItem(item) {
        if (!item.name || typeof item.name !== 'string' || item.name.trim() === '') {
            console.error('Invalid item name:', item.name);
            return false;
        }
        
        if (typeof item.quantity !== 'number' || item.quantity < 1 || item.quantity > 99) {
            console.error('Invalid quantity:', item.quantity);
            return false;
        }
        
        const validCategories = ['groceries', 'produce', 'dairy', 'meat', 'bakery', 'beverages', 'household', 'other'];
        if (!validCategories.includes(item.category)) {
            console.error('Invalid category:', item.category);
            return false;
        }
        
        return true;
    }
    
    removeItem(itemId) {
        console.log('Removing item with ID:', itemId);
        const index = this.items.findIndex(item => item.id === itemId);
        
        if (index !== -1) {
            const removedItem = this.items.splice(index, 1)[0];
            console.log('Item removed:', removedItem);
            return removedItem;
        }
        
        console.warn('Item not found with ID:', itemId);
        return null;
    }
    
    toggleItem(itemId) {
        console.log('Toggling item with ID:', itemId);
        const item = this.items.find(item => item.id === itemId);
        
        if (item) {
            item.completed = !item.completed;
            item.updatedAt = new Date().toISOString();
            console.log('Item toggled. New state:', item);
            return item;
        }
        
        console.warn('Item not found for toggling:', itemId);
        return null;
    }
    
    updateItem(itemId, updates) {
        console.log('Updating item:', itemId, updates);
        const item = this.items.find(item => item.id === itemId);
        
        if (item) {
            // Don't allow changing the ID
            const { id, ...safeUpdates } = updates;
            Object.assign(item, safeUpdates);
            item.updatedAt = new Date().toISOString();
            console.log('Item updated:', item);
            return item;
        }
        
        console.warn('Item not found for update:', itemId);
        return null;
    }
    
    getItems() {
        console.log('Getting all items. Count:', this.items.length);
        // Return copy to prevent mutation
        return [...this.items];
    }
    
    getItem(itemId) {
        console.log('Getting item with ID:', itemId);
        const item = this.items.find(item => item.id === itemId);
        console.log('Found item:', item);
        return item;
    }
    
    getStats() {
        console.log('Calculating stats...');
        const total = this.items.length;
        const completed = this.items.filter(item => item.completed).length;
        const pending = total - completed;
        
        // Count unique categories
        const categories = new Set();
        this.items.forEach(item => categories.add(item.category));
        
        const stats = {
            total,
            completed,
            pending,
            categories: categories.size
        };
        
        console.log('Stats calculated:', stats);
        return stats;
    }
    
    markAllAsCompleted() {
        console.log('Marking all items as completed');
        this.items.forEach(item => {
            item.completed = true;
            item.updatedAt = new Date().toISOString();
        });
        console.log('All items marked as completed');
    }
    
    clearCompleted() {
        console.log('Clearing completed items');
        const initialLength = this.items.length;
        this.items = this.items.filter(item => !item.completed);
        const removedCount = initialLength - this.items.length;
        console.log(`Removed ${removedCount} completed items`);
        return removedCount;
    }
    
    clearAll() {
        console.log('Clearing all items');
        const count = this.items.length;
        this.items = [];
        console.log(`Cleared all ${count} items`);
        return count;
    }
    
    getItemsByCategory(category) {
        console.log('Getting items by category:', category);
        const filteredItems = this.items.filter(item => item.category === category);
        console.log(`Found ${filteredItems.length} items in category ${category}`);
        return filteredItems;
    }
    
    getPendingItems() {
        console.log('Getting pending items');
        const pendingItems = this.items.filter(item => !item.completed);
        console.log(`Found ${pendingItems.length} pending items`);
        return pendingItems;
    }
    
    getCompletedItems() {
        console.log('Getting completed items');
        const completedItems = this.items.filter(item => item.completed);
        console.log(`Found ${completedItems.length} completed items`);
        return completedItems;
    }
    
    searchItems(searchTerm) {
        console.log('Searching items for:', searchTerm);
        const term = searchTerm.toLowerCase();
        const results = this.items.filter(item => 
            item.name.toLowerCase().includes(term) ||
            item.category.toLowerCase().includes(term)
        );
        console.log(`Found ${results.length} items matching "${searchTerm}"`);
        return results;
    }
    
    getItemsSorted(sortBy = 'name', order = 'asc') {
        console.log('Sorting items by:', sortBy, order);
        const sortedItems = [...this.items];
        
        sortedItems.sort((a, b) => {
            let aValue = a[sortBy];
            let bValue = b[sortBy];
            
            if (sortBy === 'createdAt' || sortBy === 'updatedAt') {
                aValue = new Date(aValue);
                bValue = new Date(bValue);
            }
            
            if (aValue < bValue) return order === 'asc' ? -1 : 1;
            if (aValue > bValue) return order === 'asc' ? 1 : -1;
            return 0;
        });
        
        console.log(`Sorted ${sortedItems.length} items`);
        return sortedItems;
    }
}