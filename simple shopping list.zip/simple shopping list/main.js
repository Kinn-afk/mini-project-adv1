import { ShoppingList } from './shoppingList.js';
import { UIManager } from './uiManager.js';
import { StorageManager } from './storage.js';
import { showToast } from './utilities.js';

// Initialize app
class ShoppingListApp {
    constructor() {
        this.shoppingList = new ShoppingList();
        this.uiManager = new UIManager();
        this.storageManager = new StorageManager();
        
        this.init();
    }
    
    init() {
        console.log('🚀 Initializing Shopping List App...');
        
        // Load saved items from localStorage
        const savedItems = this.storageManager.loadItems();
        console.log('Loaded items:', savedItems);
        
        savedItems.forEach(item => {
            this.shoppingList.addItem(item);
        });
        
        // Setup UIManager callbacks
        this.setupUIManagerCallbacks();
        
        // Initial render
        this.uiManager.renderList(this.shoppingList.getItems());
        this.uiManager.updateStats(this.shoppingList.getStats());
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Show welcome message
        showToast('Shopping List loaded successfully!', 'success');
        
        console.log('✅ App initialized successfully');
    }
    
    setupUIManagerCallbacks() {
        console.log('Setting up UI callbacks...');
        
        // Handle item toggle (complete/uncomplete)
        this.uiManager.onItemToggle = (itemId) => {
            console.log('Toggling item:', itemId);
            const item = this.shoppingList.toggleItem(itemId);
            if (item) {
                this.uiManager.toggleItemAnimation(itemId, item.completed);
                this.uiManager.updateStats(this.shoppingList.getStats());
                this.storageManager.saveItems(this.shoppingList.getItems());
                showToast(
                    item.completed ? `Completed: ${item.name}` : `Marked as pending: ${item.name}`,
                    item.completed ? 'success' : 'warning'
                );
            }
        };
        
        // Handle item deletion
        this.uiManager.onItemDelete = (itemId) => {
            console.log('Deleting item:', itemId);
            const item = this.shoppingList.removeItem(itemId);
            if (item) {
                this.uiManager.renderList(this.shoppingList.getItems());
                this.uiManager.updateStats(this.shoppingList.getStats());
                this.storageManager.saveItems(this.shoppingList.getItems());
                showToast(`Removed: ${item.name}`, 'error');
            }
        };
        
        // Handle filter changes
        this.uiManager.onFilterChange = (filter) => {
            console.log('Applying filter:', filter);
            this.uiManager.applyFilter(filter, this.shoppingList.getItems());
        };
    }
    
    setupEventListeners() {
        console.log('Setting up event listeners...');
        
        // Add item button
        const addItemBtn = document.getElementById('addItemBtn');
        if (addItemBtn) {
            addItemBtn.addEventListener('click', () => this.handleAddItem());
            console.log('✅ Add item button listener added');
        }
        
        // Add item on Enter key
        const itemInput = document.getElementById('itemInput');
        if (itemInput) {
            itemInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.handleAddItem();
                }
            });
            console.log('✅ Enter key listener added');
        }
        
        // Mark all as completed
        const markAllBtn = document.getElementById('markAllBtn');
        if (markAllBtn) {
            markAllBtn.addEventListener('click', () => {
                console.log('Marking all items as completed');
                this.shoppingList.markAllAsCompleted();
                this.uiManager.renderList(this.shoppingList.getItems());
                this.uiManager.updateStats(this.shoppingList.getStats());
                this.storageManager.saveItems(this.shoppingList.getItems());
                showToast('All items marked as completed!', 'success');
            });
        }
        
        // Clear completed items
        const clearCompletedBtn = document.getElementById('clearCompletedBtn');
        if (clearCompletedBtn) {
            clearCompletedBtn.addEventListener('click', () => {
                console.log('Clearing completed items');
                const removedCount = this.shoppingList.clearCompleted();
                this.uiManager.renderList(this.shoppingList.getItems());
                this.uiManager.updateStats(this.shoppingList.getStats());
                this.storageManager.saveItems(this.shoppingList.getItems());
                showToast(`Removed ${removedCount} completed item${removedCount !== 1 ? 's' : ''}`, 'warning');
            });
        }
        
        // Clear all items
        const clearAllBtn = document.getElementById('clearAllBtn');
        if (clearAllBtn) {
            clearAllBtn.addEventListener('click', () => {
                console.log('Clearing all items');
                if (confirm('Are you sure you want to clear ALL items from your shopping list?')) {
                    const removedCount = this.shoppingList.clearAll();
                    this.uiManager.renderList(this.shoppingList.getItems());
                    this.uiManager.updateStats(this.shoppingList.getStats());
                    this.storageManager.saveItems(this.shoppingList.getItems());
                    showToast(`Cleared all ${removedCount} items`, 'error');
                }
            });
        }
        
        // Filter tabs
        const filterTabs = document.querySelectorAll('.filter-tab');
        filterTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const filter = tab.dataset.filter;
                console.log('Filter clicked:', filter);
                
                // Update active tab
                filterTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                
                // Apply filter
                this.uiManager.onFilterChange(filter);
            });
        });
        
        // Module info modal
        const infoBtn = document.getElementById('infoBtn');
        const openModuleInfo = document.getElementById('openModuleInfo');
        const closeModal = document.getElementById('closeModal');
        const modal = document.getElementById('moduleModal');
        
        if (infoBtn && modal) {
            infoBtn.addEventListener('click', () => {
                console.log('Opening module info modal');
                modal.style.display = 'block';
            });
        }
        
        if (openModuleInfo && modal) {
            openModuleInfo.addEventListener('click', () => {
                console.log('Opening module info modal');
                modal.style.display = 'block';
            });
        }
        
        if (closeModal && modal) {
            closeModal.addEventListener('click', () => {
                console.log('Closing module info modal');
                modal.style.display = 'none';
            });
        }
        
        // Close modal when clicking outside
        if (modal) {
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        }
        
        console.log('✅ All event listeners set up');
    }
    
    handleAddItem() {
        const itemInput = document.getElementById('itemInput');
        const quantityInput = document.getElementById('quantityInput');
        const categorySelect = document.getElementById('categorySelect');
        
        if (!itemInput || !quantityInput || !categorySelect) {
            console.error('Input elements not found!');
            showToast('Error: Could not find input elements', 'error');
            return;
        }
        
        const name = itemInput.value.trim();
        const quantity = parseInt(quantityInput.value) || 1;
        const category = categorySelect.value;
        
        console.log('Adding item with:', { name, quantity, category });
        
        if (name) {
            if (name.length > 100) {
                showToast('Item name is too long (max 100 characters)', 'error');
                return;
            }
            
            if (quantity < 1 || quantity > 99) {
                showToast('Quantity must be between 1 and 99', 'error');
                return;
            }
            
            try {
                const newItem = this.shoppingList.addItem({ 
                    name, 
                    quantity, 
                    category 
                });
                
                console.log('Item added successfully:', newItem);
                
                // Update UI
                this.uiManager.renderList(this.shoppingList.getItems());
                this.uiManager.updateStats(this.shoppingList.getStats());
                this.uiManager.highlightItem(newItem.id);
                
                // Save to localStorage
                this.storageManager.saveItems(this.shoppingList.getItems());
                
                // Show success message
                showToast(`Added: ${name} (${quantity}x)`, 'success');
                
                // Clear inputs
                itemInput.value = '';
                quantityInput.value = '1';
                itemInput.focus();
                
            } catch (error) {
                console.error('Error adding item:', error);
                showToast('Error adding item. Please try again.', 'error');
            }
        } else {
            showToast('Please enter an item name', 'error');
            itemInput.focus();
        }
    }
}

// Start the app when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('📋 DOM fully loaded, starting app...');
    new ShoppingListApp();
});

// Export for testing or module usage
export { ShoppingListApp };